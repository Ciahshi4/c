#!/usr/bin/env bash
# One-time toolchain setup for Kali Linux (no Android Studio). Run: bash scripts/setup-kali.sh
set -euo pipefail

SDK="${ANDROID_HOME:-$HOME/android-sdk}"
GRADLE_VER="8.9"
CMDLINE_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"

echo "[1/5] JDK + tools"
sudo apt update
sudo apt install -y openjdk-21-jdk unzip wget curl adb zip || sudo apt install -y openjdk-17-jdk unzip wget curl adb zip

echo "[2/5] Android command-line tools -> $SDK"
mkdir -p "$SDK/cmdline-tools"
if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  wget -q "$CMDLINE_URL" -O /tmp/cmdline-tools.zip
  unzip -q -o /tmp/cmdline-tools.zip -d "$SDK/cmdline-tools"
  rm -rf "$SDK/cmdline-tools/latest"
  mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest"
fi

echo "[3/5] Environment variables (~/.zshrc and ~/.bashrc)"
for rc in "$HOME/.zshrc" "$HOME/.bashrc"; do
  grep -q 'CPN-ANDROID-ENV' "$rc" 2>/dev/null || cat >> "$rc" <<EOT

# CPN-ANDROID-ENV
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
export PATH="\$PATH:$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:/opt/gradle/gradle-$GRADLE_VER/bin"
EOT
done
export ANDROID_HOME="$SDK" ANDROID_SDK_ROOT="$SDK"
export PATH="$PATH:$SDK/cmdline-tools/latest/bin:$SDK/platform-tools"

echo "[4/5] SDK packages (the NDK is NOT needed: the Xray engine is a prebuilt AAR)"
yes | sdkmanager --licenses >/dev/null || true
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"

echo "[5/5] Gradle $GRADLE_VER (used once to create the wrapper)"
if [ ! -d "/opt/gradle/gradle-$GRADLE_VER" ]; then
  wget -q "https://services.gradle.org/distributions/gradle-$GRADLE_VER-bin.zip" -O /tmp/gradle.zip
  sudo mkdir -p /opt/gradle && sudo unzip -q -o /tmp/gradle.zip -d /opt/gradle
fi
echo "Done. Open a NEW terminal (or: source ~/.zshrc), then:  cd android && gradle wrapper --gradle-version $GRADLE_VER"
