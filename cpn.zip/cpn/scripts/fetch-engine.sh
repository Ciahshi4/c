#!/usr/bin/env bash
# Downloads the prebuilt Xray core AAR into android/app/libs. Run: bash scripts/fetch-engine.sh
set -euo pipefail
DEST="$(dirname "$0")/../android/app/libs"
mkdir -p "$DEST"
URL="https://github.com/2dust/AndroidLibXrayLite/releases/latest/download/libv2ray.aar"
wget -O "$DEST/libv2ray.aar" "$URL"
unzip -l "$DEST/libv2ray.aar" | grep -E 'jni/(arm64-v8a|armeabi-v7a|x86_64)/' || echo "WARNING: expected ABIs not found in the AAR"
echo "Saved $DEST/libv2ray.aar"
