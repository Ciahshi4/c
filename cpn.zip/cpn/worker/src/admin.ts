// Admin panel: a single static page. It holds no secrets; you type ADMIN_TOKEN at login
// and it is kept only in sessionStorage. All dynamic content is inserted with textContent.
export const ADMIN_HTML = String.raw`<!doctype html>
<html lang="en" dir="ltr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>CPN Admin</title>
<style>
:root{--bg:#0b0f1e;--card:#141a2e;--line:#232b47;--tx:#e8ecff;--mut:#8b95b8;--ac:#7c5cff;--ac2:#00e0c6;--bad:#ff5c7a;--ok:#2ee59d;--warn:#ffb020}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(1200px 600px at 20% -10%,#1b1550 0,transparent 60%),var(--bg);color:var(--tx);font:14px/1.5 system-ui,Segoe UI,Roboto,sans-serif}
header{display:flex;align-items:center;justify-content:space-between;padding:16px 24px;border-bottom:1px solid var(--line);backdrop-filter:blur(8px);position:sticky;top:0;background:#0b0f1ecc}
h1{font-size:18px;margin:0;background:linear-gradient(90deg,var(--ac),var(--ac2));-webkit-background-clip:text;color:transparent}
main{max-width:1200px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:20px}
.card{background:linear-gradient(160deg,#ffffff10,#ffffff05);border:1px solid var(--line);border-radius:16px;padding:16px}
.card b{display:block;font-size:26px}.card span{color:var(--mut);font-size:12px}
input,textarea,button{font:inherit;color:var(--tx);background:#0e1426;border:1px solid var(--line);border-radius:10px;padding:9px 12px}
textarea{width:100%;min-height:110px;font-family:ui-monospace,monospace;font-size:12px}
button{cursor:pointer;background:linear-gradient(90deg,var(--ac),#5b8cff);border:0;font-weight:600}
button.ghost{background:#0e1426;border:1px solid var(--line);font-weight:400}button.danger{background:var(--bad)}
.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:10px}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:10px 8px;border-bottom:1px solid var(--line);vertical-align:middle}
th{color:var(--mut);font-weight:500;font-size:12px}.wrap{overflow-x:auto}
.pill{padding:2px 8px;border-radius:99px;font-size:11px;border:1px solid var(--line)}
.on{color:var(--ok)}.off{color:var(--mut)}.bad{color:var(--bad)}.warn{color:var(--warn)}
#login{max-width:360px;margin:12vh auto;text-align:center}#err{color:var(--bad);min-height:20px;margin-top:8px}
</style></head><body>
<div id="login" class="card" hidden>
  <h1>CPN Admin</h1><p style="color:var(--mut)">Enter the admin token</p>
  <input id="tok" type="password" autocomplete="off" style="width:100%">
  <div class="row" style="justify-content:center"><button id="go">Sign in</button></div><div id="err"></div>
</div>
<div id="app" hidden>
<header><h1>CPN · Admin</h1><div class="row" style="margin:0"><button class="ghost" id="rf">Refresh</button><button class="ghost" id="out">Sign out</button></div></header>
<main>
  <div class="grid" id="stats"></div>
  <div class="card" style="margin-bottom:20px">
    <b style="font-size:16px">Add configs</b><span style="color:var(--mut)"> — one vless:// vmess:// or trojan:// link per line (names are taken from the optional prefix below)</span>
    <textarea id="lines" placeholder="vless://..."></textarea>
    <div class="row"><input id="prefix" placeholder="Name prefix (optional)"><label style="color:var(--mut)">Expires <input id="exp" type="date"></label><button id="add">Add</button><span id="addmsg"></span></div>
  </div>
  <div class="card wrap"><table><thead><tr><th>Name</th><th>Type</th><th>Status</th><th>Uses</th><th>Last used</th><th>Health</th><th>Latency</th><th>Expires</th><th></th></tr></thead><tbody id="rows"></tbody></table></div>
</main></div>
<script>
var token=sessionStorage.getItem('cpn_t')||'';
function $(s){return document.querySelector(s)}
function h(tag,props,kids){var e=document.createElement(tag);for(var k in (props||{})){if(k==='onclick')e.onclick=props[k];else if(k==='cls')e.className=props[k];else e.setAttribute(k,props[k])}
 (kids||[]).forEach(function(c){e.appendChild(typeof c==='string'?document.createTextNode(c):c)});return e}
function fmt(t){return t?new Date(t*1000).toLocaleString():'—'}
async function api(p,o){o=o||{};var r=await fetch(p,{method:o.method||'GET',body:o.body,headers:{'authorization':'Bearer '+token,'content-type':'application/json'}});
 var j={};try{j=await r.json()}catch(e){}
 if(r.status===401){sessionStorage.removeItem('cpn_t');token='';show();throw new Error('unauthorized')}
 if(!j.success&&!(j.created&&j.created.length))throw new Error(j.error||(j.errors&&j.errors[0]&&j.errors[0].error)||('HTTP '+r.status));return j}
function show(){$('#login').hidden=!!token;$('#app').hidden=!token;if(token)load()}
async function load(){
 try{var s=(await api('/api/admin/stats')).stats;var box=$('#stats');box.textContent='';
  [['Configs',s.configs],['Active',s.activeConfigs],['Total uses',s.totalUses],['Devices',s.devices],['Active 24h',s.devicesLast24h]].forEach(function(x){box.appendChild(h('div',{cls:'card'},[h('b',{},[String(x[1])]),h('span',{},[x[0]])]))});
  var list=(await api('/api/admin/configs')).configs;var tb=$('#rows');tb.textContent='';
  list.forEach(function(c){
   var exp=c.expiresAt?fmt(c.expiresAt):'never';var expired=c.expiresAt&&c.expiresAt*1000<Date.now();
   var hs=c.healthScore===null?'—':c.healthScore+'%';
   tb.appendChild(h('tr',{},[
    h('td',{},[c.name]),h('td',{},[h('span',{cls:'pill'},[c.type])]),
    h('td',{cls:c.enabled&&!expired?'on':'off'},[expired?'expired':(c.enabled?'enabled':'disabled')]),
    h('td',{},[String(c.useCount)]),h('td',{},[fmt(c.lastUsedAt)]),
    h('td',{cls:c.healthScore!==null&&c.healthScore<50?'bad':''},[hs+(c.healthFail?(' ('+c.healthFail+' fails)'):'')]),
    h('td',{},[c.avgLatencyMs===null?'—':c.avgLatencyMs+' ms']),h('td',{},[exp]),
    h('td',{},[
     h('button',{cls:'ghost',onclick:function(){toggle(c)}},[c.enabled?'Disable':'Enable']),' ',
     h('button',{cls:'ghost',onclick:function(){rename(c)}},['Rename']),' ',
     h('button',{cls:'danger',onclick:function(){del(c)}},['Delete'])])]))});
 }catch(e){}}
async function toggle(c){await api('/api/config/'+c.id,{method:'PUT',body:JSON.stringify({enabled:!c.enabled})});load()}
async function rename(c){var n=prompt('New name',c.name);if(n){await api('/api/config/'+c.id,{method:'PUT',body:JSON.stringify({name:n})});load()}}
async function del(c){if(confirm('Delete '+c.name+'?')){await api('/api/config/'+c.id,{method:'DELETE'});load()}}
$('#go').onclick=function(){token=$('#tok').value.trim();if(token){sessionStorage.setItem('cpn_t',token);$('#err').textContent='';show()}};
$('#out').onclick=function(){sessionStorage.removeItem('cpn_t');token='';show()};
$('#rf').onclick=load;
$('#add').onclick=async function(){
 var lines=$('#lines').value.split(/\r?\n/).map(function(x){return x.trim()}).filter(Boolean);var pre=$('#prefix').value.trim()||'Server';
 var d=$('#exp').value;var exp=d?Math.floor(new Date(d+'T23:59:59').getTime()/1000):null;
 var items=lines.map(function(l,i){return {name:pre+' '+(i+1),config:l,expiresAt:exp}});
 var m=$('#addmsg');m.textContent='';
 try{var r=await api('/api/configs',{method:'POST',body:JSON.stringify({items:items})});
  m.className=r.errors&&r.errors.length?'warn':'on';m.textContent='added '+r.created.length+(r.errors.length?(', rejected '+r.errors.length+' ('+r.errors[0].error+')'):'');
  $('#lines').value='';load()}catch(e){m.className='bad';m.textContent=e.message}};
setInterval(function(){if(token)load()},30000);show();
</script></body></html>`;
