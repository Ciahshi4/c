import { ADMIN_HTML } from "./admin";

export interface Env {
  DB: D1Database;
  RL?: { limit(opts: { key: string }): Promise<{ success: boolean }> };
  ADMIN_TOKEN: string;
  APP_KEY: string;
  CONFIG_TTL_SECONDS?: string;
}

type ConfigType = "vless" | "vmess" | "trojan";
const TYPES: readonly string[] = ["vless", "vmess", "trojan"];
const MAX_CONFIG_LEN = 4096;
const MAX_BULK = 200;
const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const now = () => Math.floor(Date.now() / 1000);

const json = (data: unknown, status = 200): Response =>
  new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
    },
  });
const fail = (status: number, error: string) => json({ success: false, error }, status);

/** Constant-time string comparison (compares SHA-256 digests). */
async function safeEqual(a: string, b: string): Promise<boolean> {
  const enc = new TextEncoder();
  const [x, y] = await Promise.all([
    crypto.subtle.digest("SHA-256", enc.encode(a)),
    crypto.subtle.digest("SHA-256", enc.encode(b)),
  ]);
  const xa = new Uint8Array(x), ya = new Uint8Array(y);
  let diff = 0;
  for (let i = 0; i < xa.length; i++) diff |= xa[i] ^ ya[i];
  return diff === 0;
}

async function isAdmin(req: Request, env: Env): Promise<boolean> {
  if (!env.ADMIN_TOKEN) return false;
  const h = req.headers.get("authorization") ?? "";
  if (!h.startsWith("Bearer ")) return false;
  return safeEqual(h.slice(7), env.ADMIN_TOKEN);
}

async function isApp(req: Request, env: Env): Promise<boolean> {
  if (!env.APP_KEY) return false;
  return safeEqual(req.headers.get("x-cpn-key") ?? "", env.APP_KEY);
}

function isPrivateHost(h: string): boolean {
  const host = h.replace(/^\[|\]$/g, "").toLowerCase();
  if (host === "localhost" || host.endsWith(".local") || host === "::1") return true;
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (!m) return false;
  const [a, b] = [Number(m[1]), Number(m[2])];
  return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
}

/** Server-side validation: rejects malformed, oversized, private-host or insecure-TLS configs. */
function validateConfig(type: string, config: unknown): string | null {
  if (!TYPES.includes(type)) return "type must be vless, vmess or trojan";
  if (typeof config !== "string" || config.length === 0 || config.length > MAX_CONFIG_LEN)
    return "config is empty or too long";
  if (/[\s\u0000-\u001f]/.test(config)) return "config must not contain whitespace";
  if (!config.startsWith(type + "://")) return `config must start with ${type}://`;
  let host = "";
  let port = 0;
  if (type === "vmess") {
    try {
      const o = JSON.parse(atob(config.slice(8).replace(/-/g, "+").replace(/_/g, "/")));
      host = String(o.add ?? "");
      port = Number(o.port);
      if (!o.id) return "vmess id is missing";
      if (o.allowInsecure === true || o.allowInsecure === 1 || o.allowInsecure === "1") return "insecure TLS is not allowed";
    } catch {
      return "vmess payload is not valid base64 JSON";
    }
  } else {
    const m = /^[a-z]+:\/\/([^@\/?#]+)@(\[[^\]]+\]|[^:\/?#]+):(\d{1,5})/.exec(config);
    if (!m) return "cannot parse credentials, host or port";
    host = m[2];
    port = Number(m[3]);
    if (/(allowInsecure|insecure)=(1|true)/i.test(config)) return "insecure TLS is not allowed";
  }
  if (!host || host.length > 253) return "host is invalid";
  if (!Number.isInteger(port) || port < 1 || port > 65535) return "port is invalid";
  if (isPrivateHost(host)) return "private or local hosts are not allowed";
  return null;
}

function cleanName(v: unknown, fallback: string): string {
  const s = typeof v === "string" ? v.replace(/[\u0000-\u001f<>]/g, "").trim() : "";
  return (s || fallback).slice(0, 64);
}

type Row = {
  id: string; name: string; type: string; config: string; enabled: number;
  expires_at: number | null; created_at: number; updated_at: number;
  use_count: number; last_used_at: number | null; health_ok: number; health_fail: number;
  last_health_at: number | null; avg_latency_ms: number | null;
};

const healthScore = (r: Row): number | null => {
  const t = r.health_ok + r.health_fail;
  return t === 0 ? null : Math.round((r.health_ok / t) * 100);
};

const publicView = (r: Row) => ({
  id: r.id, name: r.name, type: r.type, config: r.config,
  expiresAt: r.expires_at, healthScore: healthScore(r),
});

const adminView = (r: Row) => ({
  id: r.id, name: r.name, type: r.type, config: r.config, enabled: r.enabled === 1,
  expiresAt: r.expires_at, createdAt: r.created_at, updatedAt: r.updated_at,
  useCount: r.use_count, lastUsedAt: r.last_used_at, healthScore: healthScore(r),
  healthOk: r.health_ok, healthFail: r.health_fail, lastHealthAt: r.last_health_at,
  avgLatencyMs: r.avg_latency_ms,
});

const ACTIVE = "enabled = 1 AND (expires_at IS NULL OR expires_at > ?1)";

async function readJson(req: Request): Promise<any | null> {
  const len = Number(req.headers.get("content-length") ?? 0);
  if (len > 256 * 1024) return null;
  try { return await req.json(); } catch { return null; }
}

export default {
  async fetch(req: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(req.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";
    const method = req.method;

    if (path === "/" ) return json({ success: true, service: "cpn-api" });
    if (path === "/admin" && method === "GET") {
      return new Response(ADMIN_HTML, {
        headers: {
          "content-type": "text/html; charset=utf-8",
          "cache-control": "no-store",
          "x-frame-options": "DENY",
          "referrer-policy": "no-referrer",
          "content-security-policy":
            "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'",
        },
      });
    }
    if (!path.startsWith("/api/")) return fail(404, "not found");

    const ip = req.headers.get("cf-connecting-ip") ?? "unknown";
    const writeRoute = path.startsWith("/api/admin/") || (method !== "GET" && path !== "/api/health");
    if (env.RL) {
      const { success } = await env.RL.limit({ key: (writeRoute ? "a:" : "p:") + ip });
      if (!success) return fail(429, "rate limited");
    }

    try {
      // ---------------- Admin (Bearer ADMIN_TOKEN) ----------------
      if (writeRoute) {
        if (!(await isAdmin(req, env))) return fail(401, "unauthorized");

        if (path === "/api/admin/configs" && method === "GET") {
          const { results } = await env.DB.prepare("SELECT * FROM configs ORDER BY created_at DESC").all<Row>();
          return json({ success: true, configs: results.map(adminView) });
        }
        if (path === "/api/admin/stats" && method === "GET") {
          const t = now();
          const c = await env.DB.prepare(
            `SELECT COUNT(*) AS total, SUM(CASE WHEN ${ACTIVE} THEN 1 ELSE 0 END) AS active, COALESCE(SUM(use_count),0) AS uses FROM configs`
          ).bind(t).first<{ total: number; active: number | null; uses: number }>();
          const d = await env.DB.prepare(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN last_seen > ?1 THEN 1 ELSE 0 END) AS day FROM devices"
          ).bind(t - 86400).first<{ total: number; day: number | null }>();
          return json({
            success: true,
            stats: { configs: c?.total ?? 0, activeConfigs: c?.active ?? 0, totalUses: c?.uses ?? 0, devices: d?.total ?? 0, devicesLast24h: d?.day ?? 0 },
          });
        }

        if (path === "/api/configs" && method === "POST") {
          const body = await readJson(req);
          if (!body) return fail(400, "invalid JSON body");
          const items: any[] = Array.isArray(body.items) ? body.items : [body];
          if (items.length === 0 || items.length > MAX_BULK) return fail(400, `between 1 and ${MAX_BULK} items required`);
          const created: string[] = [];
          const errors: { index: number; error: string }[] = [];
          const t = now();
          for (let i = 0; i < items.length; i++) {
            const it = items[i] ?? {};
            const cfg = typeof it.config === "string" ? it.config.trim() : "";
            const type = typeof it.type === "string" ? it.type : cfg.split("://")[0].toLowerCase();
            const err = validateConfig(type, cfg);
            if (err) { errors.push({ index: i, error: err }); continue; }
            const id = typeof it.id === "string" && ID_RE.test(it.id) ? it.id : "cfg-" + crypto.randomUUID().slice(0, 8);
            const exp = Number.isInteger(it.expiresAt) && it.expiresAt > t ? it.expiresAt : null;
            try {
              await env.DB.prepare(
                "INSERT INTO configs (id,name,type,config,enabled,expires_at,created_at,updated_at) VALUES (?1,?2,?3,?4,?5,?6,?7,?7)"
              ).bind(id, cleanName(it.name, "Server " + (i + 1)), type, cfg, it.enabled === false ? 0 : 1, exp, t).run();
              created.push(id);
            } catch {
              errors.push({ index: i, error: "duplicate id or database error" });
            }
          }
          return json({ success: errors.length === 0, created, errors }, errors.length && !created.length ? 400 : 201);
        }

        const m = /^\/api\/config\/([A-Za-z0-9_-]{1,64})$/.exec(path);
        if (m && method === "PUT") {
          const id = m[1];
          const body = await readJson(req);
          if (!body) return fail(400, "invalid JSON body");
          const cur = await env.DB.prepare("SELECT * FROM configs WHERE id = ?1").bind(id).first<Row>();
          if (!cur) return fail(404, "config not found");
          const type = typeof body.type === "string" ? body.type : cur.type;
          const config = typeof body.config === "string" ? body.config.trim() : cur.config;
          const err = validateConfig(type, config);
          if (err) return fail(400, err);
          const exp = body.expiresAt === null ? null : Number.isInteger(body.expiresAt) ? body.expiresAt : cur.expires_at;
          await env.DB.prepare(
            "UPDATE configs SET name=?2,type=?3,config=?4,enabled=?5,expires_at=?6,updated_at=?7 WHERE id=?1"
          ).bind(id, cleanName(body.name, cur.name), type, config,
            typeof body.enabled === "boolean" ? (body.enabled ? 1 : 0) : cur.enabled, exp, now()).run();
          return json({ success: true });
        }
        if (m && method === "DELETE") {
          const r = await env.DB.prepare("DELETE FROM configs WHERE id = ?1").bind(m[1]).run();
          return r.meta.changes ? json({ success: true }) : fail(404, "config not found");
        }
        return fail(404, "not found");
      }

      // ---------------- App (X-CPN-Key) ----------------
      if (!(await isApp(req, env))) return fail(401, "unauthorized");
      const t = now();
      const ttl = Math.max(300, Number(env.CONFIG_TTL_SECONDS ?? 21600) || 21600);

      if (path === "/api/configs" && method === "GET") {
        const dev = req.headers.get("x-cpn-device") ?? "";
        if (UUID_RE.test(dev)) {
          ctx.waitUntil(
            env.DB.prepare(
              "INSERT INTO devices (device_id, first_seen, last_seen) VALUES (?1, ?2, ?2) ON CONFLICT(device_id) DO UPDATE SET last_seen = excluded.last_seen"
            ).bind(dev.toLowerCase(), t).run()
          );
        }
        const { results } = await env.DB.prepare(`SELECT * FROM configs WHERE ${ACTIVE}`).bind(t).all<Row>();
        return json({ success: true, ttl, serverTime: t, configs: results.map(publicView) });
      }
      if (path === "/api/config/random" && method === "GET") {
        const r = await env.DB.prepare(`SELECT * FROM configs WHERE ${ACTIVE} ORDER BY RANDOM() LIMIT 1`).bind(t).first<Row>();
        return r ? json({ success: true, config: publicView(r) }) : fail(404, "no active config");
      }
      const one = /^\/api\/config\/([A-Za-z0-9_-]{1,64})$/.exec(path);
      if (one && method === "GET") {
        const r = await env.DB.prepare(`SELECT * FROM configs WHERE id = ?2 AND ${ACTIVE}`).bind(t, one[1]).first<Row>();
        return r ? json({ success: true, config: publicView(r) }) : fail(404, "config not found");
      }
      if (path === "/api/health" && method === "POST") {
        const b = await readJson(req);
        if (!b || typeof b.id !== "string" || !ID_RE.test(b.id) || typeof b.ok !== "boolean") return fail(400, "invalid body");
        const lat = Number.isInteger(b.latencyMs) && b.latencyMs >= 0 && b.latencyMs < 60000 ? b.latencyMs : null;
        if (b.ok) {
          await env.DB.prepare(
            `UPDATE configs SET health_ok = health_ok + 1, use_count = use_count + 1, last_used_at = ?2, last_health_at = ?2,
             avg_latency_ms = CASE WHEN ?3 IS NULL THEN avg_latency_ms WHEN avg_latency_ms IS NULL THEN ?3 ELSE (avg_latency_ms * 7 + ?3) / 8 END
             WHERE id = ?1`
          ).bind(b.id, t, lat).run();
        } else {
          await env.DB.prepare("UPDATE configs SET health_fail = health_fail + 1, last_health_at = ?2 WHERE id = ?1").bind(b.id, t).run();
        }
        return json({ success: true });
      }
      return fail(404, "not found");
    } catch (e) {
      console.error("unhandled", e instanceof Error ? e.message : "error");
      return fail(500, "internal error");
    }
  },
} satisfies ExportedHandler<Env>;
