CREATE TABLE IF NOT EXISTS configs (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  type            TEXT NOT NULL CHECK (type IN ('vless','vmess','trojan')),
  config          TEXT NOT NULL,
  enabled         INTEGER NOT NULL DEFAULT 1,
  expires_at      INTEGER,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  use_count       INTEGER NOT NULL DEFAULT 0,
  last_used_at    INTEGER,
  health_ok       INTEGER NOT NULL DEFAULT 0,
  health_fail     INTEGER NOT NULL DEFAULT 0,
  last_health_at  INTEGER,
  avg_latency_ms  INTEGER
);
CREATE INDEX IF NOT EXISTS idx_configs_active ON configs (enabled, expires_at);

-- Privacy-first: only a random per-install UUID and two timestamps. No IP, no phone, no model.
CREATE TABLE IF NOT EXISTS devices (
  device_id  TEXT PRIMARY KEY,
  first_seen INTEGER NOT NULL,
  last_seen  INTEGER NOT NULL
);
