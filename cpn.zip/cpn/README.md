# CPN — کلاینت VPN اندروید + بک‌اند Cloudflare Worker

بدون Android Studio؛ فقط Terminal روی Kali Linux.
پروتکل‌ها: **VLESS / VMess / Trojan** (هسته‌ی Xray). دکمه‌ی روشن/خاموش، انتخاب تصادفی سرور، Failover، کانفیگ از راه دور.

```
Admin Panel (/admin) ──▶ Cloudflare Worker + D1 ──▶ APK (ConfigRepository ─▶ ServerManager(random) ─▶ CpnVpnService ─▶ Xray ─▶ Tunnel)
```

## ساختار

```
cpn/
├── scripts/setup-kali.sh        نصب JDK, SDK, Gradle روی Kali
├── scripts/fetch-engine.sh      دانلود libv2ray.aar (هسته‌ی Xray)
├── worker/                      Cloudflare Worker (TypeScript) + D1
│   ├── wrangler.jsonc  package.json  tsconfig.json
│   ├── migrations/0001_init.sql
│   └── src/index.ts (API)  src/admin.ts (پنل مدیریت)
└── android/                     پروژه‌ی Gradle (Kotlin + Compose)
    └── app/src/main/java/com/cpn/app/
        ├── CpnApp.kt MainActivity.kt MainViewModel.kt Logger.kt Format.kt
        ├── data/  Models, PreferencesManager, SecureStore, WorkerApi, ConfigRepository
        ├── vpn/   CpnVpnService, ConfigParser, XrayConfigBuilder, TunnelEngine(XrayEngine),
        │          Socks5Probe, ServerManager, ConnectionManager, Notifier, BootReceiver
        └── ui/    CpnRoot, HomeScreen, ServersScreen, StatsScreen, SettingsScreen, AboutScreen, Theme, Components
```

## انتخاب‌های فنی
- **Kotlin** (Compose + Material 3): کوتاه‌تر و امن‌تر از Java؛ Gradle بدون Studio هم آن را کامپایل می‌کند.
- **D1** برای ذخیره‌سازی: داده ساختاریافته (کانفیگ، آمار، سلامت) و کوئری‌هایی مثل `ORDER BY RANDOM()`؛ KV برای شمارنده/کوئری مناسب نیست و Durable Objects برای این کار زیادی است.
- **NDK لازم نیست**: هسته‌ی Xray به‌صورت AAR آماده (با `.so` برای `arm64-v8a`, `armeabi-v7a`, `x86_64`) استفاده می‌شود. فقط اگر بخواهید AAR را خودتان از سورس بسازید (Go + gomobile) NDK لازم است.
- AAR با **reflection** صدا زده می‌شود (`XrayEngine.kt`)؛ پروژه بدون AAR هم Build می‌شود و اگر نسخه‌ی AAR API متفاوتی داشت فقط همین یک فایل را باید تنظیم کرد.

## ۱) نصب ابزارها (یک‌بار)
```bash
cd cpn
bash scripts/setup-kali.sh
source ~/.zshrc
```
این اسکریپت JDK (۲۱ یا ۱۷)، Android cmdline-tools، `platform-tools` (adb)، `platforms;android-35`، `build-tools;35.0.0` و Gradle 8.9 را نصب و `ANDROID_HOME`/`ANDROID_SDK_ROOT`/`PATH` را تنظیم می‌کند.

## ۲) Deploy کردن Worker
```bash
cd worker
npm install
npx wrangler login
npx wrangler d1 create cpn                 # database_id را در wrangler.jsonc جایگزین کنید
npm run db:remote                          # ساخت جدول‌ها
npx wrangler secret put ADMIN_TOKEN        # یک رشته‌ی طولانی و تصادفی (openssl rand -hex 32)
npx wrangler secret put APP_KEY            # کلیدی که APK می‌فرستد (openssl rand -hex 24)
npx wrangler deploy
```
آدرس خروجی مثل `https://cpn-api.<subdomain>.workers.dev` است. پنل مدیریت: `…/admin` (توکن ادمین را وارد کنید).
تست محلی: `npm run db:local && npx wrangler dev` (secretها را در فایل `.dev.vars` بگذارید و commit نکنید).

### API
| متد | مسیر | احراز هویت | توضیح |
|---|---|---|---|
| GET | `/api/configs` | `X-CPN-Key` | کانفیگ‌های فعال و منقضی‌نشده + `ttl` |
| GET | `/api/config/random` | `X-CPN-Key` | یک کانفیگ تصادفی |
| GET | `/api/config/:id` | `X-CPN-Key` | یک کانفیگ |
| POST | `/api/health` | `X-CPN-Key` | `{"id":"…","ok":true,"latencyMs":120}` |
| POST | `/api/configs` | ادمین | `{"name","config"}` یا `{"items":[…]}` (حداکثر ۲۰۰) |
| PUT | `/api/config/:id` | ادمین | ویرایش (name/config/enabled/expiresAt) |
| DELETE | `/api/config/:id` | ادمین | حذف |
| GET | `/api/admin/configs`, `/api/admin/stats` | ادمین | برای پنل |

ادمین = `Authorization: Bearer <ADMIN_TOKEN>`. نمونه:
```bash
curl -X POST https://cpn-api.xxx.workers.dev/api/configs \
  -H "Authorization: Bearer $ADMIN_TOKEN" -H "content-type: application/json" \
  -d '{"name":"Server 1","config":"vless://UUID@host.example.com:443?type=ws&security=tls&path=%2Fws&sni=host.example.com#x"}'
```
هر کانفیگ جدید یا غیرفعال‌شده در Backend همان لحظه‌ی بعدی که کاربر Start بزند یا Refresh کند اعمال می‌شود؛ نیازی به APK جدید نیست.

## ۳) Build کردن APK
```bash
bash scripts/fetch-engine.sh                       # libv2ray.aar -> android/app/libs
cd android
gradle wrapper --gradle-version 8.9                # یک‌بار: ساخت ./gradlew
export CPN_API_BASE="https://cpn-api.xxx.workers.dev"
export CPN_APP_KEY="<همان APP_KEY>"
./gradlew assembleDebug
```
خروجی: `android/app/build/outputs/apk/debug/app-debug.apk`
(به‌جای export می‌توانید این دو مقدار را در `~/.gradle/gradle.properties` بگذارید تا وارد Git نشوند.)

## ۴) نصب و اجرا
```bash
adb devices                                        # USB debugging روشن باشد
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell am start -n com.cpn.app/.MainActivity
adb logcat -s CPN                                  # لاگ برنامه (اطلاعات حساس redact می‌شوند)
```
اولین بار که START را بزنید، خود اندروید پنجره‌ی «Connection request» را نشان می‌دهد؛ برنامه آن را دور نمی‌زند.
برای تست VPN دستگاه واقعی بهتر از امولاتور است.

## امنیت
- HTTPS اجباری (`network_security_config` + بررسی در کد)؛ بدون Cleartext.
- Worker: Rate Limit برای هر IP، مقایسه‌ی constant-time توکن‌ها، اعتبارسنجی سخت کانفیگ (scheme، host/port، حداکثر طول، ممنوعیت `allowInsecure`، ممنوعیت هاست‌های خصوصی/لوکال)، پارامترهای SQL به‌صورت bind، پنل بدون Secret و با CSP.
- APK: اعتبارسنجی دوباره‌ی کانفیگ؛ `allowInsecure` همیشه false؛ کش کانفیگ‌ها با AES-256-GCM و کلید Android Keystore؛ لاگ‌ها redact می‌شوند؛ هیچ Secretی در سورس نیست (آدرس/کلید از Gradle property می‌آید).
- پورت SOCKS محلی فقط برای تست سلامت است: فقط `127.0.0.1`، پورت و رمز تصادفی برای هر نشست.
- Privacy: فقط UUID تصادفی نصب و زمان آخرین دیده‌شدن ذخیره می‌شود. بدون شماره تلفن، مخاطبین، فایل، پیام یا موقعیت.

### محدودیت‌های امنیتی (صادقانه)
- هر کلیدی که داخل APK باشد قابل استخراج است؛ `APP_KEY` فقط جلوی ترافیک تصادفی را می‌گیرد، نه مهاجم مصمم. دفاع اصلی Rate Limit و اعتبارسنجی است. اگر کانفیگ‌ها خصوصی‌اند، لایه‌ی احراز هویت کاربر (مثلاً Cloudflare Access یا توکن به ازای کاربر) اضافه کنید.
- گزارش‌های سلامت (`/api/health`) را هر کسی با `APP_KEY` می‌تواند جعل کند؛ آن را فقط یک سیگنال بدانید.

## رفتار اتصال
Start ← دریافت لیست (در صورت خطا: کش معتبر) ← ترتیب تصادفی (SecureRandom) ← برای هر سرور: ساخت JSON Xray، اجرا، و **تست واقعی** (درخواست `generate_204` از داخل خود Xray) ← موفق = Connected، ناموفق = «Connection failed / Trying another server…» و سرور بعدی ← اگر هیچ‌کدام: «No available servers». نتیجه‌ی هر تلاش به `/api/health` گزارش می‌شود.
پایش هر ۴۵ ثانیه و تشخیص تغییر شبکه (Wi‑Fi ↔ Mobile)؛ دو شکست پیاپی = اتصال مجدد.

## قابلیت‌ها
**پیاده‌سازی شده:** Auto Connect، Auto Reconnect، Random Server، Best Server (با خاموش کردن Random)، Ping Test، Server Failover، Health Score، Config Expiration، Cache با TTL، Remote Config Update، Pull‑to‑Refresh، Favorites، Search، Manual/Auto Select، Session Timer، Data Counter، Traffic Statistics، Session History، نمودار آخرین نشست‌ها، Network Change Detection، Boot Auto Start، DNS Selection، IPv6 toggle، Dark/Light/System، فارسی/English با RTL، Notification دائمی با Disconnect/Open، Secure Config Storage، لاگ redact‌شده، بخش Advanced، قابلیت تغییر Brand (`Brand.NAME`).
**پیاده‌سازی نشده (ساختگی نشان داده نمی‌شود):**
- *Kill Switch داخل برنامه*: در اندروید فقط با «Always-on VPN + Block connections without VPN» سیستم ممکن است؛ تنظیمات یک‌ضربه باز می‌شود.
- *Split Tunneling / Per‑App VPN*: در `CpnVpnService.establish()` با `addAllowedApplication/addDisallowedApplication` ساده است ولی رابط انتخاب برنامه ساخته نشده.
- *Wi‑Fi‑only auto connect*، *Quick Settings tile*، *WorkManager برای Refresh پس‌زمینه*: عمداً در نسخه‌ی ۱ نیستند (مصرف باتری/پیچیدگی).
- آمار سرعت/حجم از شمارنده‌ی UID خود برنامه (`TrafficStats`) می‌آید، یعنی ترافیک خارجی تونل (با کمی سربار پروتکل)، نه شمارش دقیق بسته‌ها.

## تست (چک‌لیست)
Android 10…16: مجوز VPN (اولین بار و دفعات بعد)، Start/Stop، Reconnect (قطع و وصل Wi‑Fi)، Wi‑Fi→Mobile و برعکس، Background، خاموش‌شدن صفحه، Kill از Recents، Reboot (با Start on Boot)، Worker خاموش (باید از کش معتبر استفاده شود؛ بدون کش: خطا)، کانفیگ خراب (باید سرور بعدی را امتحان کند)، لیست خالی («No available servers»). برای هر مورد `adb logcat -s CPN` را ببینید.
برای شبیه‌سازی Worker خاموش: Wi‑Fi/Data را قطع کنید یا `CPN_API_BASE` را روی دامنه‌ی نامعتبر بگذارید.

## عیب‌یابی
- **«Xray engine not found»**: `libv2ray.aar` در `android/app/libs` نیست؛ `bash scripts/fetch-engine.sh` و Build دوباره.
- **«Xray AAR API mismatch»**: نسخه‌ی AAR متدهای دیگری دارد؛ فقط `vpn/XrayEngine.kt` را با API همان نسخه تنظیم کنید (`unzip -p libv2ray.aar classes.jar > c.jar && javap -cp c.jar libv2ray.Libv2ray libv2ray.CoreController`). اگر آن نسخه‌ی هسته ورودی `tun` با fd را پشتیبانی نکند، باید یک tun2socks (مثل hev-socks5-tunnel) اضافه شود.
- **Failed to find Build Tools / SDK**: `echo $ANDROID_HOME` و `sdkmanager --list_installed`.
- **Worker 401**: `APP_KEY` در Worker و `CPN_APP_KEY` هنگام Build باید یکی باشند.
