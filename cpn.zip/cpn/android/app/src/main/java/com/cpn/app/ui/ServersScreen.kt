package com.cpn.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cpn.app.MainViewModel
import com.cpn.app.data.ServerConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServersScreen(vm: MainViewModel) {
    val servers by vm.servers.collectAsStateWithLifecycle()
    val st by vm.settings.collectAsStateWithLifecycle()
    val pings by vm.pings.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var favOnly by remember { mutableStateOf(false) }

    val shown = servers
        .filter { (query.isBlank() || it.name.contains(query, true)) && (!favOnly || it.id in st.favorites) }
        .sortedWith(compareByDescending<ServerConfig> { it.id in st.favorites }.thenBy { pings[it.id]?.takeIf { p -> p >= 0 } ?: Int.MAX_VALUE })

    PullToRefreshBox(isRefreshing = refreshing, onRefresh = { vm.refresh() }, modifier = Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("Servers", "سرورها"), fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = { vm.pingAll() }) { Icon(Icons.Rounded.Speed, tr("Test ping", "تست پینگ")) }
                }
            }
            item {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text(tr("Search servers", "جستجوی سرور")) }, modifier = Modifier.fillMaxWidth()
                )
                FilterChip(
                    selected = favOnly, onClick = { favOnly = !favOnly },
                    label = { Text(tr("Favorites only", "فقط علاقه‌مندی‌ها")) }, modifier = Modifier.padding(top = 8.dp)
                )
            }
            item {
                GlassCard(Modifier.fillMaxWidth().clickable { vm.update { it.copy(selectedId = null) } }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(st.selectedId == null, { vm.update { it.copy(selectedId = null) } })
                        Icon(Icons.Rounded.Public, null, tint = Teal)
                        Column(Modifier.padding(start = 10.dp)) {
                            Text(tr("Auto Select", "انتخاب خودکار"), fontWeight = FontWeight.SemiBold)
                            Text(
                                tr("Random server with automatic failover", "سرور تصادفی با جایگزینی خودکار"),
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            if (shown.isEmpty()) item {
                Text(
                    tr("No servers yet. Pull down to refresh.", "هنوز سروری نیست. برای به‌روزرسانی به پایین بکشید."),
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(24.dp)
                )
            }
            items(shown, key = { it.id }) { s ->
                val ping = pings[s.id]
                GlassCard(Modifier.fillMaxWidth().clickable { vm.update { it.copy(selectedId = s.id) } }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(st.selectedId == s.id, { vm.update { it.copy(selectedId = s.id) } })
                        Column(Modifier.weight(1f).padding(start = 6.dp)) {
                            Text(s.name, fontWeight = FontWeight.SemiBold)
                            val health = s.healthScore?.let { "$it%" } ?: "—"
                            val p = when { ping == null -> "—"; ping < 0 -> tr("timeout", "بدون پاسخ"); else -> "$ping ms" }
                            Text(
                                "${s.type.uppercase()}  ·  ${tr("Ping", "پینگ")} $p  ·  ${tr("Health", "سلامت")} $health",
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = {
                            vm.update { cur -> cur.copy(favorites = if (s.id in cur.favorites) cur.favorites - s.id else cur.favorites + s.id) }
                        }) {
                            val fav = s.id in st.favorites
                            Icon(if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder, null, tint = if (fav) Amber else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
