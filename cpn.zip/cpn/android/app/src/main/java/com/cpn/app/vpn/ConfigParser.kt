package com.cpn.app.vpn

import android.util.Base64
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import java.net.URLDecoder

/** Normalised view of a vless:// vmess:// trojan:// link. */
data class Endpoint(
    val type: String,
    val host: String,
    val port: Int,
    val secret: String,                 // uuid (vless/vmess) or password (trojan)
    val p: Map<String, String>,         // normalised params: network, security, sni, host, path, alpn, fp, flow, ...
)

object ConfigParser {
    class ParseException(msg: String) : Exception(msg)

    private val URL_RE = Regex("^[a-z]+://([^@/?#]+)@(\\[[^\\]]+\\]|[^:/?#]+):(\\d{1,5})/?(?:\\?([^#]*))?(?:#.*)?$")

    fun parse(type: String, uri: String): Endpoint {
        if (uri.length > 4096 || !uri.startsWith("$type://")) throw ParseException("bad scheme or length")
        if (uri.any { it.isWhitespace() || it.code < 32 }) throw ParseException("whitespace in config")
        if (Regex("(allowInsecure|insecure)=(1|true)", RegexOption.IGNORE_CASE).containsMatchIn(uri))
            throw ParseException("insecure TLS is not allowed")
        val ep = when (type) {
            "vless", "trojan" -> parseUrlStyle(type, uri)
            "vmess" -> parseVmess(uri)
            else -> throw ParseException("unsupported type")
        }
        if (ep.host.isBlank() || ep.port !in 1..65535 || ep.secret.isBlank()) throw ParseException("invalid host/port/id")
        return ep
    }

    private fun dec(s: String) = URLDecoder.decode(s, "UTF-8")

    private fun parseUrlStyle(type: String, uri: String): Endpoint {
        val m = URL_RE.matchEntire(uri) ?: throw ParseException("cannot parse link")
        val q = HashMap<String, String>()
        m.groupValues[4].split('&').filter { it.isNotEmpty() }.forEach {
            val i = it.indexOf('=')
            if (i > 0) q[it.substring(0, i)] = dec(it.substring(i + 1))
        }
        val p = HashMap<String, String>()
        p["network"] = q["type"] ?: "tcp"
        p["security"] = q["security"] ?: if (type == "trojan") "tls" else "none"
        q["sni"]?.let { p["sni"] = it }
        q["host"]?.let { p["host"] = it }
        q["path"]?.let { p["path"] = it }
        q["alpn"]?.let { p["alpn"] = it }
        q["fp"]?.let { p["fp"] = it }
        q["flow"]?.let { p["flow"] = it }
        q["encryption"]?.let { p["encryption"] = it }
        q["pbk"]?.let { p["pbk"] = it }
        q["sid"]?.let { p["sid"] = it }
        q["spx"]?.let { p["spx"] = it }
        q["serviceName"]?.let { p["serviceName"] = it }
        return Endpoint(type, m.groupValues[2].trim('[', ']'), m.groupValues[3].toInt(), dec(m.groupValues[1]), p)
    }

    private fun parseVmess(uri: String): Endpoint {
        val raw = uri.removePrefix("vmess://").replace('-', '+').replace('_', '/')
        val o: JsonObject = try {
            Json.parseToJsonElement(String(Base64.decode(raw, Base64.DEFAULT))).jsonObject
        } catch (e: Exception) { throw ParseException("bad vmess payload") }
        fun s(k: String) = (o[k] as? JsonPrimitive)?.content ?: ""
        val p = HashMap<String, String>()
        p["network"] = s("net").ifBlank { "tcp" }
        p["security"] = if (s("tls") == "tls") "tls" else "none"
        s("sni").takeIf { it.isNotBlank() }?.let { p["sni"] = it }
        s("host").takeIf { it.isNotBlank() }?.let { p["host"] = it }
        s("path").takeIf { it.isNotBlank() }?.let { p["path"] = it }
        s("alpn").takeIf { it.isNotBlank() }?.let { p["alpn"] = it }
        s("fp").takeIf { it.isNotBlank() }?.let { p["fp"] = it }
        p["aid"] = s("aid").ifBlank { "0" }
        p["scy"] = s("scy").ifBlank { "auto" }
        if (p["network"] == "grpc") p["serviceName"] = s("path")
        val port = s("port").toIntOrNull() ?: throw ParseException("bad port")
        return Endpoint("vmess", s("add"), port, s("id"), p)
    }
}
