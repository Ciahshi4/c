package com.cpn.app.vpn

import android.content.Context
import android.content.Intent
import com.cpn.app.data.Status
import com.cpn.app.data.VpnUi
import kotlinx.coroutines.flow.MutableStateFlow

/** Process-wide VPN state shared between the service and the UI. */
object ConnectionManager {
    val state = MutableStateFlow(VpnUi())

    fun connect(ctx: Context) {
        ctx.startForegroundService(Intent(ctx, CpnVpnService::class.java).setAction(CpnVpnService.ACTION_START))
    }

    fun disconnect(ctx: Context) {
        if (state.value.status == Status.DISCONNECTED) return
        ctx.startService(Intent(ctx, CpnVpnService::class.java).setAction(CpnVpnService.ACTION_STOP))
    }
}
