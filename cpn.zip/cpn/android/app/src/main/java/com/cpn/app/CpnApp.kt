package com.cpn.app

import android.app.Application
import android.content.Context
import com.cpn.app.data.ConfigRepository
import com.cpn.app.data.PreferencesManager
import com.cpn.app.data.SecureStore
import com.cpn.app.data.WorkerApi
import com.cpn.app.vpn.Notifier
import java.io.File

/** Change these two to re-brand the app (UI strings and notification title). */
object Brand {
    const val NAME = "CPN"
}

class CpnApp : Application() {
    val prefs by lazy { PreferencesManager(this) }
    val api by lazy { WorkerApi(prefs) }
    val repo by lazy { ConfigRepository(api, SecureStore(File(filesDir, "configs.bin"))) }

    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannels(this)
    }
}

val Context.app: CpnApp get() = applicationContext as CpnApp

/** Tiny bilingual helper: English / Persian. */
fun pick(lang: String, en: String, fa: String) = if (lang == "fa") fa else en
