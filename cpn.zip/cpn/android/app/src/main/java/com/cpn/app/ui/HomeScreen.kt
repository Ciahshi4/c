package com.cpn.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cpn.app.Brand
import com.cpn.app.MainViewModel
import com.cpn.app.data.Status
import com.cpn.app.fmtBytes
import com.cpn.app.fmtDuration
import com.cpn.app.fmtSpeed
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(vm: MainViewModel, onToggle: () -> Unit) {
    val ui by vm.vpn.collectAsStateWithLifecycle()
    val servers by vm.servers.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(ui.status) {
        while (ui.status == Status.CONNECTED) { now = System.currentTimeMillis(); delay(1000) }
    }

    val title = when (ui.status) {
        Status.CONNECTED -> tr("Connected", "متصل شد")
        Status.CONNECTING -> ui.message.ifBlank { tr("Connecting…", "در حال اتصال…") }
        Status.ERROR -> ui.message
        Status.DISCONNECTED -> tr("Not connected", "متصل نیستید")
    }
    val sub = when (ui.status) {
        Status.CONNECTED -> tr("Protected", "محافظت‌شده")
        Status.DISCONNECTED -> tr("Tap to connect", "برای اتصال بزنید")
        Status.ERROR -> tr("Tap to try again", "برای تلاش دوباره بزنید")
        Status.CONNECTING -> ""
    }
    val statusColor = when (ui.status) {
        Status.CONNECTED -> Green; Status.CONNECTING -> Amber; Status.ERROR -> Red
        Status.DISCONNECTED -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val elapsed = if (ui.status == Status.CONNECTED) (now - ui.connectedAt) / 1000 else 0L

    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(18.dp))
        Text(Brand.NAME, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp)
        Spacer(Modifier.weight(1f))
        PowerButton(ui.status, onToggle)
        Spacer(Modifier.height(10.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = statusColor, textAlign = TextAlign.Center)
        if (sub.isNotEmpty()) Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Text(fmtDuration(elapsed), fontSize = 38.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Light)
        Spacer(Modifier.weight(1f))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(Modifier.weight(1f), true, tr("Download", "دانلود"), fmtSpeed(ui.rxSpeed))
            StatCard(Modifier.weight(1f), false, tr("Upload", "آپلود"), fmtSpeed(ui.txSpeed))
        }
        Spacer(Modifier.height(12.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoRow(tr("Server", "سرور"), if (ui.status == Status.DISCONNECTED || ui.serverName.isBlank()) "Auto" else ui.serverName)
                InfoRow(tr("Status", "وضعیت"), if (ui.status == Status.CONNECTED) tr("Protected", "محافظت‌شده") else tr("Not protected", "محافظت‌نشده"))
                InfoRow(tr("Data used", "حجم مصرفی"), fmtBytes(ui.rxBytes + ui.txBytes))
                InfoRow(tr("Available servers", "سرورهای موجود"), servers.size.toString())
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun StatCard(modifier: Modifier, down: Boolean, label: String, value: String) {
    GlassCard(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (down) Icons.Rounded.ArrowDownward else Icons.Rounded.ArrowUpward, null,
                tint = if (down) Teal else Violet, modifier = Modifier.size(26.dp)
            )
            Column(Modifier.padding(start = 10.dp)) {
                Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun InfoRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, fontWeight = FontWeight.Medium)
    }
}
