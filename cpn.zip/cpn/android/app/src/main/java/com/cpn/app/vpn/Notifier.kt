package com.cpn.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import com.cpn.app.Brand
import com.cpn.app.MainActivity
import com.cpn.app.R
import com.cpn.app.app
import com.cpn.app.pick

object Notifier {
    enum class Mode { CONNECTING, CONNECTED }

    private const val CH = "cpn_vpn"
    private const val CH_MIN = "cpn_vpn_min"

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "VPN status", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_MIN, "VPN status (minimal)", NotificationManager.IMPORTANCE_MIN))
    }

    fun build(c: Context, mode: Mode): Notification {
        val st = c.app.prefs.state.value
        val l = st.language
        val title = if (mode == Mode.CONNECTED) pick(l, "VPN Connected", "VPN متصل است")
        else pick(l, "Connecting…", "در حال اتصال…")
        val text = if (mode == Mode.CONNECTED) pick(l, "Protected", "محافظت‌شده") else Brand.NAME

        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            c, 1, Intent(c, CpnVpnService::class.java).setAction(CpnVpnService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val icon = Icon.createWithResource(c, R.drawable.ic_stat_cpn)
        return Notification.Builder(c, if (st.notifications) CH else CH_MIN)
            .setSmallIcon(R.drawable.ic_stat_cpn)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(icon, pick(l, "Disconnect", "قطع اتصال"), stop).build())
            .addAction(Notification.Action.Builder(icon, pick(l, "Open app", "باز کردن برنامه"), open).build())
            .build()
    }
}
