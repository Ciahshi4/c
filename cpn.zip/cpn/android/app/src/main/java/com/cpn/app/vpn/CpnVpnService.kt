package com.cpn.app.vpn

import android.app.Notification
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.Process
import android.os.SystemClock
import com.cpn.app.Logger
import com.cpn.app.app
import com.cpn.app.data.ServerConfig
import com.cpn.app.data.SessionRecord
import com.cpn.app.data.Settings
import com.cpn.app.data.Status
import com.cpn.app.data.VpnUi
import com.cpn.app.pick
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.security.SecureRandom

class CpnVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.cpn.app.START"
        const val ACTION_STOP = "com.cpn.app.STOP"
        private const val NOTIF_ID = 1
    }

    private class Probe(val port: Int, val user: String, val pass: String)
    private class Attempt(val ok: Boolean, val latencyMs: Int? = null)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val state get() = ConnectionManager.state
    private var job: Job? = null
    private var statsJob: Job? = null
    private var monitorJob: Job? = null
    private var tun: ParcelFileDescriptor? = null
    private var probe: Probe? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var baseRx = 0L
    private var baseTx = 0L
    private lateinit var engine: TunnelEngine

    private val settings get() = app.prefs.state.value
    private fun t(en: String, fa: String) = pick(settings.language, en, fa)

    override fun onCreate() {
        super.onCreate()
        engine = XrayEngine(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            scope.launch { shutdown() }
            return START_NOT_STICKY
        }
        promote(Notifier.build(this, Notifier.Mode.CONNECTING))
        if (job?.isActive != true) job = scope.launch { connectFlow() }
        return START_NOT_STICKY
    }

    private fun promote(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        else startForeground(NOTIF_ID, n)
    }

    // ---------------------------------------------------------------- connect flow

    private suspend fun connectFlow() {
        val st = settings
        Logger.i("VPN started")
        state.value = VpnUi(Status.CONNECTING, t("Fetching servers…", "در حال دریافت سرورها…"))
        Logger.i("Fetching configs")
        val servers = app.repo.getActiveConfigs()
        if (servers.isEmpty()) { fail(t("No available servers\nPlease try again later.", "سروری در دسترس نیست\nلطفاً بعداً دوباره تلاش کنید.")); return }

        var first = true
        for (s in ServerManager.order(servers, st)) {
            state.value = VpnUi(
                Status.CONNECTING,
                if (first) t("Connecting…", "در حال اتصال…") else t("Connection failed\nTrying another server…", "اتصال ناموفق بود\nتلاش با سرور دیگر…"),
                serverName = if (st.selectedId == null) "Auto" else s.name,
            )
            first = false
            Logger.i("Config selected: ${s.name}")
            Logger.i("Connecting")
            val a = try {
                tryServer(s, st)
            } catch (e: EngineMissingException) {
                fail(e.message ?: "Engine missing"); return
            }
            scope.launch { app.repo.report(s.id, a.ok, a.latencyMs) }
            if (a.ok) { onConnected(s, st); return }
            Logger.w("Config failed: ${s.name}")
        }
        fail(t("No available servers\nPlease try again later.", "سروری در دسترس نیست\nلطفاً بعداً دوباره تلاش کنید."))
    }

    private suspend fun tryServer(s: ServerConfig, st: Settings): Attempt = withContext(Dispatchers.IO) {
        try {
            val ep = ConfigParser.parse(s.type, s.config)
            val creds = Probe(freePort(), token(8), token(16))
            val json = XrayConfigBuilder.build(ep, ServerManager.dnsAddress(st.dns), creds.port, creds.user, creds.pass)
            val pfd = tun ?: establish(st).also { tun = it } ?: throw IOException("VPN permission was revoked")
            engine.start(json, pfd.fd)
            probe = creds
            val t0 = SystemClock.elapsedRealtime()
            delay(700)
            var ok = false
            repeat(3) { if (!ok) ok = Socks5Probe.run(creds.port, creds.user, creds.pass) }
            if (ok) Attempt(true, (SystemClock.elapsedRealtime() - t0).toInt())
            else { runCatching { engine.stop() }; Attempt(false) }
        } catch (e: EngineMissingException) {
            throw e
        } catch (e: Exception) {
            Logger.e("Attempt error: ${e.javaClass.simpleName}")
            runCatching { engine.stop() }
            Attempt(false)
        }
    }

    private fun establish(st: Settings): ParcelFileDescriptor? {
        val b = Builder()
            .setSession("CPN")
            .setMtu(1500)
            .addAddress("10.10.14.2", 30)
            .addRoute("0.0.0.0", 0)
            .addDnsServer(ServerManager.dnsAddress(st.dns))
            .setMetered(false)
        if (st.ipv6) b.addAddress("fd00:10:10::2", 126).addRoute("::", 0)
        // Our own sockets (Xray -> proxy server, API calls, ping) must NOT loop back into the tunnel.
        runCatching { b.addDisallowedApplication(packageName) }
        return b.establish()
    }

    private fun onConnected(s: ServerConfig, st: Settings) {
        baseRx = TrafficStats.getUidRxBytes(Process.myUid()).coerceAtLeast(0)
        baseTx = TrafficStats.getUidTxBytes(Process.myUid()).coerceAtLeast(0)
        state.value = VpnUi(
            Status.CONNECTED, "Protected",
            serverName = if (st.selectedId == null) "Auto" else s.name,
            connectedAt = System.currentTimeMillis(),
        )
        Logger.i("Connected")
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, Notifier.build(this, Notifier.Mode.CONNECTED))
        startStats()
        startMonitor()
        registerNetwork()
    }

    private fun fail(msg: String) {
        Logger.e("Error: ${msg.replace('\n', ' ')}")
        statsJob?.cancel(); monitorJob?.cancel()
        unregisterNetwork()
        runCatching { engine.stop() }
        runCatching { tun?.close() }
        tun = null
        state.value = VpnUi(Status.ERROR, msg)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------------------------------------------------------------- runtime: stats, health, network

    private fun startStats() {
        statsJob?.cancel()
        statsJob = scope.launch {
            var lastRx = 0L
            var lastTx = 0L
            while (isActive) {
                delay(1000)
                val rx = (TrafficStats.getUidRxBytes(Process.myUid()) - baseRx).coerceAtLeast(0)
                val tx = (TrafficStats.getUidTxBytes(Process.myUid()) - baseTx).coerceAtLeast(0)
                state.update { it.copy(rxBytes = rx, txBytes = tx, rxSpeed = (rx - lastRx).coerceAtLeast(0), txSpeed = (tx - lastTx).coerceAtLeast(0)) }
                lastRx = rx; lastTx = tx
            }
        }
    }

    private suspend fun probeOnce(): Boolean = withContext(Dispatchers.IO) {
        probe?.let { Socks5Probe.run(it.port, it.user, it.pass) } ?: false
    }

    private fun startMonitor() {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            var failures = 0
            while (isActive) {
                delay(45_000)
                if (probeOnce()) failures = 0 else if (++failures >= 2) { reconnect(); return@launch }
            }
        }
    }

    private fun reconnect() {
        Logger.w("Connection lost; reconnecting")
        saveSession()
        statsJob?.cancel()
        job = scope.launch {
            runCatching { withContext(Dispatchers.IO) { engine.stop() } }
            connectFlow()
        }
        monitorJob?.cancel()
    }

    private fun registerNetwork() {
        if (netCb != null) return
        val cm = getSystemService(ConnectivityManager::class.java)
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (cm.getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) return
                setUnderlyingNetworks(arrayOf(network))
                if (state.value.status == Status.CONNECTED) {
                    Logger.i("Network changed")
                    scope.launch { delay(1500); if (state.value.status == Status.CONNECTED && !probeOnce()) reconnect() }
                }
            }
        }
        runCatching { cm.registerDefaultNetworkCallback(cb); netCb = cb }
    }

    private fun unregisterNetwork() {
        netCb?.let { runCatching { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } }
        netCb = null
    }

    // ---------------------------------------------------------------- shutdown

    private fun saveSession() {
        val cur = state.value
        if (cur.status != Status.CONNECTED) return
        app.prefs.addSession(
            SessionRecord(cur.connectedAt, (System.currentTimeMillis() - cur.connectedAt) / 1000, cur.rxBytes, cur.txBytes, cur.serverName)
        )
    }

    private suspend fun shutdown() {
        saveSession()
        job?.cancel(); statsJob?.cancel(); monitorJob?.cancel()
        unregisterNetwork()
        withContext(Dispatchers.IO) {
            runCatching { engine.stop() }
            runCatching { tun?.close() }
        }
        tun = null
        state.value = VpnUi(Status.DISCONNECTED)
        Logger.i("Disconnected")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        // The user turned the VPN off from system settings, or another VPN app took over.
        scope.launch { shutdown() }
    }

    override fun onDestroy() {
        runCatching { engine.stop() }
        runCatching { tun?.close() }
        unregisterNetwork()
        scope.cancel()
        if (state.value.status == Status.CONNECTED || state.value.status == Status.CONNECTING) state.value = VpnUi(Status.DISCONNECTED)
        super.onDestroy()
    }

    private fun freePort(): Int = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1")).use { it.localPort }

    private fun token(bytes: Int): String {
        val b = ByteArray(bytes).also { SecureRandom().nextBytes(it) }
        return b.joinToString("") { "%02x".format(it) }
    }
}
