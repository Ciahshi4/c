package com.cpn.app.vpn

import java.io.BufferedReader
import java.io.DataInputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Real end-to-end check: HTTP 204 request to cp.cloudflare.com sent THROUGH Xray (loopback SOCKS5 with
 * auth) and therefore through the selected proxy server. If this succeeds the config really works.
 */
object Socks5Probe {
    fun run(port: Int, user: String, pass: String, timeoutMs: Int = 6000): Boolean = try {
        Socket().use { s ->
            s.connect(InetSocketAddress("127.0.0.1", port), 2000)
            s.soTimeout = timeoutMs
            val out = s.getOutputStream()
            val inp = DataInputStream(s.getInputStream())
            out.write(byteArrayOf(5, 1, 2)); out.flush()
            if (inp.readUnsignedByte() != 5 || inp.readUnsignedByte() != 2) return false
            val u = user.toByteArray(); val p = pass.toByteArray()
            out.write(byteArrayOf(1, u.size.toByte()) + u + byteArrayOf(p.size.toByte()) + p); out.flush()
            inp.readUnsignedByte()
            if (inp.readUnsignedByte() != 0) return false
            val host = "cp.cloudflare.com".toByteArray()
            out.write(byteArrayOf(5, 1, 0, 3, host.size.toByte()) + host + byteArrayOf(0, 80)); out.flush()
            inp.readUnsignedByte()
            if (inp.readUnsignedByte() != 0) return false
            inp.readUnsignedByte()
            when (inp.readUnsignedByte()) {
                1 -> inp.skipBytes(4)
                3 -> inp.skipBytes(inp.readUnsignedByte())
                4 -> inp.skipBytes(16)
            }
            inp.skipBytes(2)
            out.write("GET /generate_204 HTTP/1.1\r\nHost: cp.cloudflare.com\r\nConnection: close\r\n\r\n".toByteArray())
            out.flush()
            val line = BufferedReader(InputStreamReader(inp)).readLine() ?: return false
            line.contains(" 204")
        }
    } catch (e: Exception) { false }
}
