package com.cpn.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cpn.app.Logger
import com.cpn.app.MainViewModel
import com.cpn.app.vpn.ConfigParser

@Composable
fun SettingsScreen(vm: MainViewModel, onOpenVpnSettings: () -> Unit) {
    val st by vm.settings.collectAsStateWithLifecycle()
    val servers by vm.servers.collectAsStateWithLifecycle()
    var advanced by remember { mutableStateOf(false) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(tr("Settings", "تنظیمات"), fontSize = 24.sp, fontWeight = FontWeight.Bold) }

        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Text(tr("Appearance", "ظاهر"), fontWeight = FontWeight.SemiBold)
                    Chips(
                        listOf("system" to tr("System", "سیستم"), "dark" to tr("Dark", "تیره"), "light" to tr("Light", "روشن")),
                        st.theme
                    ) { v -> vm.update { it.copy(theme = v) } }
                    Text(tr("Language", "زبان"), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
                    Chips(listOf("en" to "English", "fa" to "فارسی"), st.language) { v -> vm.update { it.copy(language = v) } }
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    SettingSwitch(tr("Auto Connect", "اتصال خودکار"), tr("Connect when the app opens (after permission was granted once)", "هنگام باز شدن برنامه وصل شود (پس از یک‌بار دادن مجوز)"), st.autoConnect) { v -> vm.update { it.copy(autoConnect = v) } }
                    SettingSwitch(tr("Random Server", "سرور تصادفی"), tr("Off = prefer the healthiest server", "خاموش = سالم‌ترین سرور اولویت دارد"), st.randomServer) { v -> vm.update { it.copy(randomServer = v) } }
                    SettingSwitch(tr("Start on Boot", "اجرا هنگام روشن شدن"), tr("Only works if VPN permission was already granted", "فقط اگر مجوز VPN قبلاً داده شده باشد"), st.startOnBoot) { v -> vm.update { it.copy(startOnBoot = v) } }
                    SettingSwitch(tr("Notifications", "اعلان‌ها"), tr("Off = minimal silent notification (Android requires one)", "خاموش = اعلان حداقلی (اندروید حتماً یکی لازم دارد)"), st.notifications) { v -> vm.update { it.copy(notifications = v) } }
                    SettingSwitch("IPv6", tr("Route IPv6 through the tunnel", "عبور IPv6 از تونل"), st.ipv6) { v -> vm.update { it.copy(ipv6 = v) } }
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Text("DNS", fontWeight = FontWeight.SemiBold)
                    Chips(listOf("cloudflare" to "Cloudflare 1.1.1.1", "google" to "Google 8.8.8.8", "quad9" to "Quad9 9.9.9.9"), st.dns) { v -> vm.update { it.copy(dns = v) } }
                    Text(tr("Applies on the next connection.", "از اتصال بعدی اعمال می‌شود."), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Text(tr("Kill Switch", "کیل سوییچ"), fontWeight = FontWeight.SemiBold)
                    Text(
                        tr(
                            "A real kill switch is an Android system feature: enable \"Always-on VPN\" and \"Block connections without VPN\" for this app.",
                            "کیل سوییچ واقعی قابلیت خود اندروید است: «Always-on VPN» و «Block connections without VPN» را برای این برنامه فعال کنید."
                        ),
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp)
                    )
                    OutlinedButton(onClick = onOpenVpnSettings) { Text(tr("Open system VPN settings", "باز کردن تنظیمات VPN سیستم")) }
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    SettingSwitch(tr("Advanced", "پیشرفته"), tr("Technical details and logs (secrets are redacted)", "جزئیات فنی و لاگ (اطلاعات حساس پنهان است)"), advanced) { advanced = it }
                    if (advanced) {
                        Text(tr("Servers (type host:port)", "سرورها (نوع میزبان:پورت)"), fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp))
                        servers.forEach { s ->
                            val hp = try { ConfigParser.parse(s.type, s.config).let { "${it.host}:${it.port}" } } catch (e: Exception) { "?" }
                            Text("${s.id}  ${s.type}  $hp", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }
                        Text(tr("Log", "لاگ"), fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp))
                        Text(
                            Logger.snapshot().takeLast(40).joinToString("\n").ifBlank { "—" },
                            fontFamily = FontFamily.Monospace, fontSize = 10.sp
                        )
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { vm.clearCache() }) { Text(tr("Clear config cache", "پاک‌کردن کش")) }
                            OutlinedButton(onClick = { vm.clearSessions() }) { Text(tr("Clear history", "پاک‌کردن تاریخچه")) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Chips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { (key, label) ->
            FilterChip(selected = selected == key, onClick = { onSelect(key) }, label = { Text(label) })
        }
    }
}
