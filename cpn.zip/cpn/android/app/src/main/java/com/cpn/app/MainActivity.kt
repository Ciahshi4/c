package com.cpn.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cpn.app.data.Status
import com.cpn.app.ui.CpnApp as CpnRoot
import com.cpn.app.ui.CpnTheme
import com.cpn.app.ui.LocalLang

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    // The system itself shows "Connection request – this app wants to set up a VPN connection".
    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) vm.connect()
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        // Auto Connect: only if permission was already granted earlier (we never skip the system prompt).
        if (savedInstanceState == null && vm.settings.value.autoConnect &&
            vm.vpn.value.status == Status.DISCONNECTED && VpnService.prepare(this) == null
        ) vm.connect()

        setContent {
            val st by vm.settings.collectAsStateWithLifecycle()
            val dark = when (st.theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
            CompositionLocalProvider(
                LocalLang provides st.language,
                LocalLayoutDirection provides if (st.language == "fa") LayoutDirection.Rtl else LayoutDirection.Ltr,
            ) {
                CpnTheme(dark) {
                    CpnRoot(vm, dark, onToggle = ::toggle, onOpenVpnSettings = {
                        startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
                    })
                }
            }
        }
    }

    private fun toggle() {
        val s = vm.vpn.value.status
        if (s == Status.CONNECTED || s == Status.CONNECTING) { vm.disconnect(); return }
        val intent = VpnService.prepare(this)
        if (intent == null) vm.connect() else vpnPermission.launch(intent)
    }
}
