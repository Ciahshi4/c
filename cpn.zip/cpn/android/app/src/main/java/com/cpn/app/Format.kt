package com.cpn.app

import java.util.Locale

fun fmtBytes(b: Long): String {
    val v = b.toDouble()
    return when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> String.format(Locale.US, "%.0f KB", v / 1024)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", v / (1024 * 1024))
        else -> String.format(Locale.US, "%.2f GB", v / (1024.0 * 1024 * 1024))
    }
}

fun fmtSpeed(bytesPerSec: Long) = fmtBytes(bytesPerSec) + "/s"

fun fmtDuration(totalSec: Long): String {
    val s = totalSec.coerceAtLeast(0)
    return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}
