package com.cpn.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.util.Locale
import java.util.UUID

class PreferencesManager(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cpn_prefs", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    private val sessionSer = ListSerializer(SessionRecord.serializer())

    private val _state = MutableStateFlow(load())
    val state: StateFlow<Settings> = _state

    private val _sessions = MutableStateFlow(loadSessions())
    val sessions: StateFlow<List<SessionRecord>> = _sessions

    private fun load() = Settings(
        theme = sp.getString("theme", "system")!!,
        autoConnect = sp.getBoolean("autoConnect", false),
        randomServer = sp.getBoolean("randomServer", true),
        startOnBoot = sp.getBoolean("startOnBoot", false),
        dns = sp.getString("dns", "cloudflare")!!,
        notifications = sp.getBoolean("notifications", true),
        language = sp.getString("language", if (Locale.getDefault().language == "fa") "fa" else "en")!!,
        ipv6 = sp.getBoolean("ipv6", false),
        selectedId = sp.getString("selected", null),
        favorites = sp.getStringSet("fav", emptySet())!!.toSet(),
    )

    @Synchronized
    fun update(block: (Settings) -> Settings) {
        val n = block(_state.value)
        sp.edit()
            .putString("theme", n.theme)
            .putBoolean("autoConnect", n.autoConnect)
            .putBoolean("randomServer", n.randomServer)
            .putBoolean("startOnBoot", n.startOnBoot)
            .putString("dns", n.dns)
            .putBoolean("notifications", n.notifications)
            .putString("language", n.language)
            .putBoolean("ipv6", n.ipv6)
            .putString("selected", n.selectedId)
            .putStringSet("fav", n.favorites)
            .apply()
        _state.value = n
    }

    /** Random per-install id. Not derived from hardware, phone number or account. */
    val deviceId: String
        @Synchronized get() = sp.getString("device", null)
            ?: UUID.randomUUID().toString().also { sp.edit().putString("device", it).apply() }

    private fun loadSessions(): List<SessionRecord> = try {
        json.decodeFromString(sessionSer, sp.getString("sessions", "[]")!!)
    } catch (e: Exception) { emptyList() }

    @Synchronized
    fun addSession(r: SessionRecord) {
        if (r.durationSec < 3) return
        val list = (listOf(r) + _sessions.value).take(200)
        sp.edit().putString("sessions", json.encodeToString(sessionSer, list)).apply()
        _sessions.value = list
    }

    @Synchronized
    fun clearSessions() {
        sp.edit().remove("sessions").apply()
        _sessions.value = emptyList()
    }
}
