package com.cpn.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cpn.app.data.Settings
import com.cpn.app.vpn.ConnectionManager
import com.cpn.app.vpn.ServerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val a = application as CpnApp

    val vpn = ConnectionManager.state
    val settings = a.prefs.state
    val servers = a.repo.servers
    val sessions = a.prefs.sessions
    val pings = MutableStateFlow<Map<String, Int>>(emptyMap())   // -1 = unreachable
    val refreshing = MutableStateFlow(false)

    init {
        viewModelScope.launch(Dispatchers.IO) {
            a.repo.loadCachedIntoState()
            if (a.repo.isStale()) refresh()
        }
    }

    fun refresh() {
        viewModelScope.launch {
            refreshing.value = true
            a.repo.refresh()
            refreshing.value = false
        }
    }

    fun pingAll() {
        viewModelScope.launch {
            val list = servers.value
            pings.value = list.map { s -> async(Dispatchers.IO) { s.id to (ServerManager.ping(s) ?: -1) } }.awaitAll().toMap()
        }
    }

    fun update(block: (Settings) -> Settings) = a.prefs.update(block)
    fun connect() = ConnectionManager.connect(a)
    fun disconnect() = ConnectionManager.disconnect(a)
    fun clearCache() = a.repo.clearCache()
    fun clearSessions() = a.prefs.clearSessions()
}
