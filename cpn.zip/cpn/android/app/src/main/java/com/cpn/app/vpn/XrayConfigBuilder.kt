package com.cpn.app.vpn

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/**
 * Builds the Xray JSON from a parsed endpoint.
 *  - "tun-in":   Xray reads packets straight from the VpnService file descriptor
 *  - "probe-in": loopback SOCKS5 (random port + random credentials) used only by our own health probe
 */
object XrayConfigBuilder {
    private val ALLOWED_NETWORKS = setOf("tcp", "ws", "grpc", "httpupgrade")

    fun build(ep: Endpoint, dnsServer: String, probePort: Int, probeUser: String, probePass: String): String {
        val root = buildJsonObject {
            putJsonObject("log") { put("loglevel", "warning") }
            putJsonObject("dns") { putJsonArray("servers") { add(kotlinx.serialization.json.JsonPrimitive(dnsServer)) } }
            putJsonArray("inbounds") {
                addJsonObject {
                    put("tag", "tun-in")
                    put("protocol", "tun")
                    putJsonObject("settings") { put("name", "xray0"); put("MTU", 1500); put("userLevel", 0) }
                }
                addJsonObject {
                    put("tag", "probe-in")
                    put("listen", "127.0.0.1")
                    put("port", probePort)
                    put("protocol", "socks")
                    putJsonObject("settings") {
                        put("auth", "password")
                        put("udp", false)
                        putJsonArray("accounts") { addJsonObject { put("user", probeUser); put("pass", probePass) } }
                    }
                }
            }
            putJsonArray("outbounds") {
                add(outbound(ep))
                addJsonObject { put("tag", "direct"); put("protocol", "freedom") }
                addJsonObject { put("tag", "block"); put("protocol", "blackhole") }
                addJsonObject { put("tag", "dns-out"); put("protocol", "dns") }
            }
            putJsonObject("routing") {
                put("domainStrategy", "AsIs")
                putJsonArray("rules") {
                    addJsonObject {
                        put("type", "field")
                        put("inboundTag", buildJsonArray { add(kotlinx.serialization.json.JsonPrimitive("tun-in")) })
                        put("port", "53")
                        put("outboundTag", "dns-out")
                    }
                }
            }
        }
        return root.toString()
    }

    private fun outbound(ep: Endpoint): JsonObject = buildJsonObject {
        put("tag", "proxy")
        put("protocol", ep.type)
        putJsonObject("settings") {
            when (ep.type) {
                "vless" -> putJsonArray("vnext") {
                    addJsonObject {
                        put("address", ep.host); put("port", ep.port)
                        putJsonArray("users") {
                            addJsonObject {
                                put("id", ep.secret)
                                put("encryption", ep.p["encryption"] ?: "none")
                                ep.p["flow"]?.takeIf { it.isNotBlank() }?.let { put("flow", it) }
                            }
                        }
                    }
                }
                "vmess" -> putJsonArray("vnext") {
                    addJsonObject {
                        put("address", ep.host); put("port", ep.port)
                        putJsonArray("users") {
                            addJsonObject {
                                put("id", ep.secret)
                                put("alterId", ep.p["aid"]?.toIntOrNull() ?: 0)
                                put("security", ep.p["scy"] ?: "auto")
                            }
                        }
                    }
                }
                "trojan" -> putJsonArray("servers") {
                    addJsonObject { put("address", ep.host); put("port", ep.port); put("password", ep.secret) }
                }
            }
        }
        put("streamSettings", stream(ep))
    }

    private fun stream(ep: Endpoint): JsonObject = buildJsonObject {
        val net = ep.p["network"] ?: "tcp"
        if (net !in ALLOWED_NETWORKS) throw ConfigParser.ParseException("unsupported transport: $net")
        put("network", net)
        val sec = ep.p["security"] ?: "none"
        put("security", sec)
        val sni = ep.p["sni"] ?: ep.p["host"] ?: ep.host
        val fp = ep.p["fp"] ?: "chrome"
        when (sec) {
            "tls" -> putJsonObject("tlsSettings") {
                put("serverName", sni)
                put("fingerprint", fp)
                put("allowInsecure", false)
                ep.p["alpn"]?.takeIf { it.isNotBlank() }?.let { a ->
                    putJsonArray("alpn") { a.split(',').forEach { add(kotlinx.serialization.json.JsonPrimitive(it.trim())) } }
                }
            }
            "reality" -> putJsonObject("realitySettings") {
                put("serverName", ep.p["sni"] ?: ep.host)
                put("fingerprint", fp)
                put("publicKey", ep.p["pbk"] ?: throw ConfigParser.ParseException("reality publicKey missing"))
                put("shortId", ep.p["sid"] ?: "")
                put("spiderX", ep.p["spx"] ?: "/")
            }
            "none" -> {}
            else -> throw ConfigParser.ParseException("unsupported security: $sec")
        }
        when (net) {
            "ws" -> putJsonObject("wsSettings") {
                put("path", ep.p["path"] ?: "/")
                ep.p["host"]?.takeIf { it.isNotBlank() }?.let { h -> putJsonObject("headers") { put("Host", h) } }
            }
            "grpc" -> putJsonObject("grpcSettings") { put("serviceName", ep.p["serviceName"] ?: "") }
            "httpupgrade" -> putJsonObject("httpupgradeSettings") {
                put("path", ep.p["path"] ?: "/")
                ep.p["host"]?.takeIf { it.isNotBlank() }?.let { put("host", it) }
            }
        }
    }
}
