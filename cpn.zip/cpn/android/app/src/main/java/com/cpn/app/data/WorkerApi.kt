package com.cpn.app.data

import com.cpn.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

class WorkerApi(private val prefs: PreferencesManager) {
    // One shared client = connection pooling / keep-alive.
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()
    private val json = Json { ignoreUnknownKeys = true }

    private fun base(): String {
        val b = BuildConfig.API_BASE
        if (!b.startsWith("https://")) throw IOException("API base must use HTTPS")
        return b
    }

    private fun req(path: String) = Request.Builder()
        .url(base() + path)
        .header("X-CPN-Key", BuildConfig.APP_KEY)
        .header("X-CPN-Device", prefs.deviceId)
        .header("User-Agent", "CPN/${BuildConfig.VERSION_NAME}")

    suspend fun fetchConfigs(): ConfigsResponse = withContext(Dispatchers.IO) {
        client.newCall(req("/api/configs").get().build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val body = r.body?.string() ?: throw IOException("empty body")
            if (body.length > 2_000_000) throw IOException("response too large")
            val res = json.decodeFromString(ConfigsResponse.serializer(), body)
            if (!res.success) throw IOException(res.error ?: "request failed")
            res
        }
    }

    suspend fun reportHealth(id: String, ok: Boolean, latencyMs: Int?) {
        withContext(Dispatchers.IO) {
            try {
                val body: JsonObject = buildJsonObject {
                    put("id", id)
                    put("ok", ok)
                    if (latencyMs != null) put("latencyMs", latencyMs)
                }
                val rb = body.toString().toRequestBody("application/json".toMediaType())
                client.newCall(req("/api/health").post(rb).build()).execute().close()
            } catch (_: Exception) { /* best effort */ }
        }
    }
}
