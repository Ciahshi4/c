package com.cpn.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cpn.app.BuildConfig
import com.cpn.app.Brand

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(tr("About", "درباره"), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        GlassCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoRow(tr("App", "برنامه"), Brand.NAME)
                InfoRow(tr("Version", "نسخه"), BuildConfig.VERSION_NAME)
                InfoRow(tr("Developer", "توسعه‌دهنده"), "Amir")
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Column {
                Text(tr("Privacy Policy", "حریم خصوصی"), fontWeight = FontWeight.SemiBold)
                Text(
                    tr(
                        "This app sends only a random install ID and the result of server health checks to its config server. No phone number, contacts, files, messages or location are ever read. Your traffic is not logged.",
                        "این برنامه فقط یک شناسه‌ی تصادفی نصب و نتیجه‌ی تست سلامت سرورها را به سرور کانفیگ می‌فرستد. شماره تلفن، مخاطبین، فایل‌ها، پیام‌ها و موقعیت مکانی هرگز خوانده نمی‌شوند. ترافیک شما ثبت نمی‌شود."
                    ),
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Column {
                Text(tr("Open-source licenses", "مجوزهای متن‌باز"), fontWeight = FontWeight.SemiBold)
                Text(
                    "Xray-core (MPL-2.0) · AndroidLibXrayLite (LGPL-3.0) · AndroidX / Jetpack Compose (Apache-2.0) · OkHttp (Apache-2.0) · kotlinx.serialization / coroutines (Apache-2.0)",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}
