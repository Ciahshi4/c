package com.cpn.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.cpn.app.MainViewModel

@Composable
fun CpnApp(vm: MainViewModel, dark: Boolean, onToggle: () -> Unit, onOpenVpnSettings: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val items: List<Pair<String, ImageVector>> = listOf(
        tr("Home", "خانه") to Icons.Rounded.Home,
        tr("Servers", "سرورها") to Icons.Rounded.Dns,
        tr("Stats", "آمار") to Icons.Rounded.BarChart,
        tr("Settings", "تنظیمات") to Icons.Rounded.Settings,
        tr("About", "درباره") to Icons.Rounded.Info,
    )
    Box(Modifier.fillMaxSize().background(backgroundBrush(dark))) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Color.Transparent) {
                    items.forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, label) }, label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(indicatorColor = Violet.copy(alpha = 0.25f)),
                        )
                    }
                }
            }
        ) { inner ->
            Box(Modifier.padding(inner).statusBarsPadding()) {
                Crossfade(tab, label = "tabs") { t ->
                    when (t) {
                        0 -> HomeScreen(vm, onToggle)
                        1 -> ServersScreen(vm)
                        2 -> StatsScreen(vm)
                        3 -> SettingsScreen(vm, onOpenVpnSettings)
                        else -> AboutScreen()
                    }
                }
            }
        }
    }
}
