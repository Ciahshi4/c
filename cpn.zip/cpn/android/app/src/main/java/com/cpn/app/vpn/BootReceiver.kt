package com.cpn.app.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.cpn.app.app

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        // Only if the user enabled it AND already granted the system VPN permission.
        if (context.app.prefs.state.value.startOnBoot && VpnService.prepare(context) == null) {
            ConnectionManager.connect(context)
        }
    }
}
