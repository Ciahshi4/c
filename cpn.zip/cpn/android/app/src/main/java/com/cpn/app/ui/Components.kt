package com.cpn.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.cpn.app.data.Status
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

@Composable
fun PowerButton(status: Status, onClick: () -> Unit) {
    val color by animateColorAsState(
        when (status) {
            Status.CONNECTED -> Green
            Status.CONNECTING -> Amber
            Status.ERROR -> Red
            Status.DISCONNECTED -> Violet
        }, tween(500), label = "color"
    )
    val inf = rememberInfiniteTransition(label = "inf")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "rot")
    val pulse by inf.animateFloat(0.95f, 1.06f, infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val shake = remember { Animatable(0f) }
    LaunchedEffect(status) {   // error animation
        if (status == Status.ERROR) {
            repeat(3) { shake.animateTo(14f, tween(50)); shake.animateTo(-14f, tween(50)) }
            shake.animateTo(0f, tween(50))
        }
    }
    val surface = MaterialTheme.colorScheme.surface

    Box(
        Modifier
            .offset { IntOffset(shake.value.dp.roundToPx(), 0) }
            .size(240.dp)
            .scale(if (status == Status.CONNECTED) pulse else 1f),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2
            drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.38f), Color.Transparent), radius = r), radius = r)
            val stroke = 9.dp.toPx()
            val d = size.minDimension - 56.dp.toPx()
            val tl = Offset((size.width - d) / 2, (size.height - d) / 2)
            if (status == Status.CONNECTING) {
                rotate(rot) {
                    drawArc(
                        Brush.sweepGradient(listOf(Color.Transparent, color), center), 0f, 280f, false, tl, Size(d, d),
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                }
            } else {
                drawCircle(color.copy(alpha = 0.85f), radius = d / 2, style = Stroke(stroke))
            }
        }
        Box(
            Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(surface)
                .border(1.dp, color.copy(alpha = 0.5f), CircleShape)
                .clickable(remember { MutableInteractionSource() }, indication = null, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.PowerSettingsNew, null, tint = color, modifier = Modifier.size(68.dp))
        }
    }
}

@Composable
fun SettingSwitch(title: String, subtitle: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked, onChange)
    }
}
