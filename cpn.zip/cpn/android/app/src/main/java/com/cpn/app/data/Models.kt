package com.cpn.app.data

import kotlinx.serialization.Serializable

@Serializable
data class ServerConfig(
    val id: String,
    val name: String,
    val type: String,
    val config: String,
    val expiresAt: Long? = null,
    val healthScore: Int? = null,
)

@Serializable
data class ConfigsResponse(
    val success: Boolean = false,
    val ttl: Long = 21600,
    val serverTime: Long = 0,
    val configs: List<ServerConfig> = emptyList(),
    val error: String? = null,
)

@Serializable
data class ConfigCache(val fetchedAt: Long, val ttlSeconds: Long, val configs: List<ServerConfig>)

@Serializable
data class SessionRecord(
    val startedAt: Long,
    val durationSec: Long,
    val rxBytes: Long,
    val txBytes: Long,
    val server: String,
)

enum class Status { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class VpnUi(
    val status: Status = Status.DISCONNECTED,
    val message: String = "",
    val serverName: String = "",
    val connectedAt: Long = 0,
    val rxBytes: Long = 0,
    val txBytes: Long = 0,
    val rxSpeed: Long = 0,
    val txSpeed: Long = 0,
)

data class Settings(
    val theme: String = "system",          // system | dark | light
    val autoConnect: Boolean = false,
    val randomServer: Boolean = true,
    val startOnBoot: Boolean = false,
    val dns: String = "cloudflare",        // cloudflare | google | quad9
    val notifications: Boolean = true,
    val language: String = "en",           // en | fa
    val ipv6: Boolean = false,
    val selectedId: String? = null,        // null = Auto
    val favorites: Set<String> = emptySet(),
)
