package com.cpn.app

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** In-memory ring buffer + logcat. Anything that looks like a config, UUID, token or password is redacted. */
object Logger {
    private val buf = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val secret = Regex(
        "(vless|vmess|trojan)://\\S+|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|(token|password|pass|key|secret)[=:]\\S+",
        RegexOption.IGNORE_CASE
    )

    fun redact(s: String) = secret.replace(s, "[redacted]")

    @Synchronized
    private fun add(level: Char, msg: String) {
        val clean = redact(msg)
        buf.addLast("${fmt.format(Date())} $level $clean")
        while (buf.size > 200) buf.removeFirst()
        when (level) {
            'E' -> Log.e("CPN", clean)
            'W' -> Log.w("CPN", clean)
            else -> Log.i("CPN", clean)
        }
    }

    fun i(m: String) = add('I', m)
    fun w(m: String) = add('W', m)
    fun e(m: String) = add('E', m)

    @Synchronized
    fun snapshot(): List<String> = buf.toList()
}
