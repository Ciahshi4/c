package com.cpn.app.data

import com.cpn.app.Logger
import com.cpn.app.vpn.ConfigParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.Json

class ConfigRepository(private val api: WorkerApi, private val store: SecureStore) {
    private val json = Json { ignoreUnknownKeys = true }
    private val _servers = MutableStateFlow<List<ServerConfig>>(emptyList())
    val servers: StateFlow<List<ServerConfig>> = _servers
    @Volatile private var lastFetchMs = 0L

    private fun nowSec() = System.currentTimeMillis() / 1000

    /** Client-side validation: drop expired entries and anything the parser rejects. */
    private fun clean(list: List<ServerConfig>): List<ServerConfig> {
        val t = nowSec()
        return list.filter { s ->
            (s.expiresAt == null || s.expiresAt > t) && try {
                ConfigParser.parse(s.type, s.config); true
            } catch (e: Exception) {
                Logger.w("Dropped invalid config ${s.id}"); false
            }
        }
    }

    private fun readCache(): ConfigCache? = try {
        store.read()?.let { json.decodeFromString(ConfigCache.serializer(), it.decodeToString()) }
    } catch (e: Exception) { null }

    /** Cached list, only if still inside its TTL. Expired/disabled configs never come back from here. */
    fun cachedValid(): List<ServerConfig> {
        val c = readCache() ?: return emptyList()
        if (nowSec() - c.fetchedAt > c.ttlSeconds) return emptyList()
        return clean(c.configs)
    }

    fun loadCachedIntoState() { _servers.value = cachedValid() }

    fun isStale(): Boolean = System.currentTimeMillis() - lastFetchMs > 15 * 60_000

    /** Network first (so a config added/disabled in the backend takes effect immediately); falls back to valid cache. */
    suspend fun getActiveConfigs(): List<ServerConfig> {
        try {
            val res = api.fetchConfigs()
            val list = clean(res.configs)
            store.write(json.encodeToString(ConfigCache.serializer(), ConfigCache(nowSec(), res.ttl, list)).encodeToByteArray())
            lastFetchMs = System.currentTimeMillis()
            _servers.value = list
            Logger.i("Fetched ${list.size} configs")
            return list
        } catch (e: Exception) {
            Logger.w("Worker unavailable (${e.javaClass.simpleName}); using cache")
            val cached = cachedValid()
            _servers.value = cached
            return cached
        }
    }

    suspend fun refresh(): Boolean {
        val before = lastFetchMs
        getActiveConfigs()
        return lastFetchMs != before
    }

    suspend fun report(id: String, ok: Boolean, latencyMs: Int?) = api.reportHealth(id, ok, latencyMs)

    fun clearCache() { store.clear(); _servers.value = emptyList() }
}
