package com.cpn.app.vpn

import android.os.SystemClock
import com.cpn.app.data.ServerConfig
import com.cpn.app.data.Settings
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import kotlin.random.asKotlinRandom

object ServerManager {
    private val rng = SecureRandom().asKotlinRandom()

    /** TCP connect time to the server in ms (null = unreachable). Our own app is excluded from the VPN, so this is always direct. */
    fun ping(s: ServerConfig): Int? = try {
        val ep = ConfigParser.parse(s.type, s.config)
        val t = SystemClock.elapsedRealtime()
        Socket().use { it.connect(InetSocketAddress(ep.host, ep.port), 3000) }
        (SystemClock.elapsedRealtime() - t).toInt()
    } catch (e: Exception) { null }

    /**
     * Order in which servers are tried (failover = walk this list).
     * - manual selection first (if any), then the rest shuffled
     * - Random Server on: cryptographically random shuffle
     * - Random Server off ("Best"): by backend health score
     */
    fun order(servers: List<ServerConfig>, st: Settings): List<ServerConfig> {
        val chosen = st.selectedId?.let { id -> servers.find { it.id == id } }
        if (chosen != null) return listOf(chosen) + servers.filter { it !== chosen }.shuffled(rng)
        return if (st.randomServer) servers.shuffled(rng)
        else servers.sortedByDescending { it.healthScore ?: 50 }
    }

    fun dnsAddress(key: String) = when (key) {
        "google" -> "8.8.8.8"
        "quad9" -> "9.9.9.9"
        else -> "1.1.1.1"
    }
}
