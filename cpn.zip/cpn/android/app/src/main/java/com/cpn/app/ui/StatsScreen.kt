package com.cpn.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cpn.app.MainViewModel
import com.cpn.app.fmtBytes
import com.cpn.app.fmtDuration
import java.text.DateFormat
import java.util.Date

@Composable
fun StatsScreen(vm: MainViewModel) {
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val rx = sessions.sumOf { it.rxBytes }
    val tx = sessions.sumOf { it.txBytes }
    val time = sessions.sumOf { it.durationSec }
    val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text(tr("Statistics", "آمار"), fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoRow(tr("Download", "دانلود"), fmtBytes(rx))
                    InfoRow(tr("Upload", "آپلود"), fmtBytes(tx))
                    InfoRow(tr("Total traffic", "کل ترافیک"), fmtBytes(rx + tx))
                    InfoRow(tr("Connection time", "مدت اتصال"), fmtDuration(time))
                    InfoRow(tr("Sessions", "نشست‌ها"), sessions.size.toString())
                }
            }
        }
        item {
            val last = sessions.take(7).reversed()
            val max = (last.maxOfOrNull { it.rxBytes + it.txBytes } ?: 1L).coerceAtLeast(1L)
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Text(tr("Last sessions (traffic)", "آخرین نشست‌ها (ترافیک)"), fontWeight = FontWeight.Medium)
                    Canvas(Modifier.fillMaxWidth().height(110.dp).padding(top = 12.dp)) {
                        val n = 7
                        val gap = 10.dp.toPx()
                        val w = (size.width - gap * (n - 1)) / n
                        last.forEachIndexed { i, s ->
                            val h = ((s.rxBytes + s.txBytes).toFloat() / max) * size.height
                            drawRoundRect(
                                Brush.verticalGradient(listOf(Teal, Violet), startY = size.height - h, endY = size.height),
                                topLeft = Offset(i * (w + gap), size.height - h.coerceAtLeast(4f)),
                                size = Size(w, h.coerceAtLeast(4f)), cornerRadius = CornerRadius(8.dp.toPx())
                            )
                        }
                    }
                }
            }
        }
        item { Text(tr("Session history", "تاریخچه نشست‌ها"), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp)) }
        if (sessions.isEmpty()) item {
            Text(tr("No sessions yet.", "هنوز نشستی ثبت نشده."), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(sessions.take(50)) { s ->
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Text(df.format(Date(s.startedAt)), fontWeight = FontWeight.Medium)
                    Text(
                        "${fmtDuration(s.durationSec)}  ·  ↓ ${fmtBytes(s.rxBytes)}  ↑ ${fmtBytes(s.txBytes)}  ·  ${s.server}",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
