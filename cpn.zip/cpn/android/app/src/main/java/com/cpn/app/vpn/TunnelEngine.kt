package com.cpn.app.vpn

import android.content.Context
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Proxy

interface TunnelEngine {
    /** Starts packet processing on [tunFd] with the given Xray JSON. Must not block. */
    fun start(configJson: String, tunFd: Int)
    fun stop()
}

class EngineMissingException(msg: String) : Exception(msg)

/**
 * Xray core via the prebuilt AAR (2dust/AndroidLibXrayLite -> app/libs/libv2ray.aar).
 *
 * The AAR is called through reflection so the project compiles even without it, and so
 * that a different AAR version only requires changing THIS file. API expected (v1.8.x+):
 *   Libv2ray.initCoreEnv(String assetsPath, String xudpKey)
 *   Libv2ray.newCoreController(CoreCallbackHandler) -> CoreController
 *   CoreController.startLoop(String configJson, int tunFd) / stopLoop()
 */
class XrayEngine(private val context: Context) : TunnelEngine {
    private var controller: Any? = null

    private fun unwrap(e: Throwable): Throwable = (e as? InvocationTargetException)?.targetException ?: e

    override fun start(configJson: String, tunFd: Int) {
        val lib = try { Class.forName("libv2ray.Libv2ray") } catch (e: ClassNotFoundException) {
            throw EngineMissingException("Xray engine not found. Put libv2ray.aar in app/libs and rebuild.")
        }
        try {
            val handlerType = Class.forName("libv2ray.CoreCallbackHandler")
            val handler = Proxy.newProxyInstance(handlerType.classLoader, arrayOf(handlerType)) { _, m, _ ->
                when (m.name) {
                    "hashCode" -> 0
                    "equals" -> false
                    "toString" -> "CpnCoreHandler"
                    else -> 0L   // startup / shutdown / onEmitStatus return a Long
                }
            }
            lib.getMethod("initCoreEnv", String::class.java, String::class.java)
                .invoke(null, context.filesDir.absolutePath, "")
            val ctrl = lib.getMethod("newCoreController", handlerType).invoke(null, handler)
                ?: throw IllegalStateException("newCoreController returned null")
            ctrl.javaClass.getMethod("startLoop", String::class.java, Int::class.javaPrimitiveType)
                .invoke(ctrl, configJson, tunFd)
            controller = ctrl
        } catch (e: ReflectiveOperationException) {
            throw IllegalStateException("Xray AAR API mismatch (${unwrap(e).javaClass.simpleName}); adjust XrayEngine.kt", unwrap(e))
        }
    }

    override fun stop() {
        val c = controller ?: return
        controller = null
        try { c.javaClass.getMethod("stopLoop").invoke(c) } catch (_: Exception) { }
    }
}
