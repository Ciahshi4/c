package com.cpn.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Violet = Color(0xFF7C5CFF)
val Teal = Color(0xFF00E0C6)
val Green = Color(0xFF2EE59D)
val Amber = Color(0xFFFFB020)
val Red = Color(0xFFFF5C7A)

val LocalLang = compositionLocalOf { "en" }

/** Translate inline: tr("English", "فارسی"). */
@Composable
fun tr(en: String, fa: String): String = if (LocalLang.current == "fa") fa else en

private val Dark = darkColorScheme(
    primary = Violet, secondary = Teal, background = Color(0xFF0B0F1E), surface = Color(0xFF141A2E),
    onBackground = Color(0xFFE8ECFF), onSurface = Color(0xFFE8ECFF), surfaceVariant = Color(0xFF1B2240),
    onSurfaceVariant = Color(0xFF8B95B8),
)
private val Light = lightColorScheme(
    primary = Color(0xFF5B3FE0), secondary = Color(0xFF00A892), background = Color(0xFFF3F5FF), surface = Color.White,
    onBackground = Color(0xFF12172B), onSurface = Color(0xFF12172B), surfaceVariant = Color(0xFFE6EAFB),
    onSurfaceVariant = Color(0xFF5B6486),
)

@Composable
fun CpnTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}

@Composable
fun backgroundBrush(dark: Boolean): Brush = if (dark)
    Brush.verticalGradient(listOf(Color(0xFF1B1550), Color(0xFF0B0F1E), Color(0xFF07101F)))
else
    Brush.verticalGradient(listOf(Color(0xFFE1DBFF), Color(0xFFF3F5FF), Color(0xFFE6FBF7)))

/** Translucent "glass" card (gradient fill + hairline border). */
@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val on = MaterialTheme.colorScheme.onSurface
    val shape = RoundedCornerShape(22.dp)
    Box(
        modifier
            .background(Brush.linearGradient(listOf(on.copy(alpha = 0.10f), on.copy(alpha = 0.04f))), shape)
            .border(1.dp, on.copy(alpha = 0.12f), shape)
            .padding(16.dp)
    ) { content() }
}
