# The Xray AAR is accessed by reflection.
-keep class libv2ray.** { *; }
-keep class go.** { *; }
-keepattributes *Annotation*, InnerClasses
-keep,includedescriptorclasses class com.cpn.app.**$$serializer { *; }
-keepclassmembers class com.cpn.app.** { *** Companion; }
-keepclasseswithmembers class com.cpn.app.** { kotlinx.serialization.KSerializer serializer(...); }
